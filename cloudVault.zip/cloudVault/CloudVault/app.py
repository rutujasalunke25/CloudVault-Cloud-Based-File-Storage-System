
import os
import mimetypes
from pathlib import Path
from uuid import uuid4
from io import BytesIO
from functools import wraps

from dotenv import load_dotenv
from supabase import create_client

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    send_file,
    session,
)

from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash


# ==================================================
# CONFIGURATION
# ==================================================

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env", override=True)

SUPABASE_URL = os.getenv("SUPABASE_URL", "").strip()
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY", "").strip()
FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "").strip()

print("\n========== SUPABASE CONFIGURATION ==========")
print("Supabase URL:", SUPABASE_URL or "MISSING")
print("Key variable loaded:", bool(SUPABASE_KEY))

if SUPABASE_KEY.startswith("sb_publishable_"):
    print("Key type: PUBLISHABLE KEY — NOT SUITABLE HERE")
elif SUPABASE_KEY.startswith("sb_secret_"):
    print("Key type: Secret key prefix detected")
elif SUPABASE_KEY.startswith("eyJ"):
    print("Key type: Legacy JWT-style key detected")
else:
    print("Key type: Unknown — verify in Supabase Dashboard")

print("Flask secret loaded:", bool(FLASK_SECRET_KEY))
print("============================================\n")

if not SUPABASE_URL or not SUPABASE_KEY:
    raise RuntimeError(
        "SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY missing in .env"
    )

if SUPABASE_KEY.startswith("sb_publishable_"):
    raise RuntimeError(
        "Wrong Supabase key! Get the actual Secret key from "
        "Supabase Dashboard > Project Settings > API Keys."
    )

if not FLASK_SECRET_KEY or FLASK_SECRET_KEY == "YOUR_RANDOM_SECRET":
    raise RuntimeError(
        "Set a generated random FLASK_SECRET_KEY in your .env file."
    )

app = Flask(__name__)
app.secret_key = FLASK_SECRET_KEY

BUCKET_NAME = "CloudVault-files"

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)


# ==================================================
# LOGIN REQUIRED
# ==================================================

def login_required(view_function):
    @wraps(view_function)
    def wrapped_view(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.")
            return redirect(url_for("login"))

        return view_function(*args, **kwargs)

    return wrapped_view


# ==================================================
# HOME — OPEN LOGIN PAGE DIRECTLY
# ==================================================

@app.route("/")
def home():
    return redirect(url_for("login"))


# ==================================================
# SIGNUP
# ==================================================

@app.route("/signup", methods=["GET", "POST"])
def signup():

    if request.method == "POST":

        full_name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not all([full_name, email, password, confirm_password]):
            flash("Please fill in all fields.")
            return redirect(url_for("signup"))

        if len(password) < 8:
            flash("Password must contain at least 8 characters.")
            return redirect(url_for("signup"))

        if password != confirm_password:
            flash("Passwords do not match.")
            return redirect(url_for("signup"))

        try:
            existing_user = (
                supabase.table("users")
                .select("id")
                .eq("email", email)
                .limit(1)
                .execute()
            )

            if existing_user.data:
                flash("This email is already registered.")
                return redirect(url_for("signup"))

            password_hash = generate_password_hash(password)

            result = supabase.table("users").insert({
                "full_name": full_name,
                "email": email,
                "password_hash": password_hash,
            }).execute()

            if result.data:
                flash("Account created successfully! Please log in.")
                return redirect(url_for("login"))

            flash("Account was not created. Please try again.")
            return redirect(url_for("signup"))

        except Exception as exc:
            app.logger.exception("Signup failed")

            error_message = str(exc).lower()

            if "row-level security" in error_message:
                flash(
                    "Signup blocked by Supabase database permissions. "
                    "Check the server terminal."
                )
            elif "invalid api key" in error_message:
                flash(
                    "Invalid Supabase API key. Check your .env configuration."
                )
            else:
                flash("Signup failed. Check the server terminal.")

            return redirect(url_for("signup"))

    return render_template("signin.html")


# ==================================================
# LOGIN
# ==================================================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not email or not password:
            flash("Please enter email and password.")
            return redirect(url_for("login"))

        try:
            result = (
                supabase.table("users")
                .select("id, full_name, email, password_hash")
                .eq("email", email)
                .limit(1)
                .execute()
            )

            if not result.data:
                flash("Invalid email or password.")
                return redirect(url_for("login"))

            user = result.data[0]

            if not check_password_hash(user["password_hash"], password):
                flash("Invalid email or password.")
                return redirect(url_for("login"))

            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["full_name"]
            session["user_email"] = user["email"]

            flash("Login successful!")
            return redirect(url_for("dashboard"))

        except Exception:
            app.logger.exception("Login failed")
            flash("Login failed. Check the server terminal.")
            return redirect(url_for("login"))

    return render_template("login.html")


# ==================================================
# LOGOUT
# ==================================================

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("home"))


# ==================================================
# DASHBOARD
# ==================================================

@app.route("/dashboard")
@login_required
def dashboard():

    files = []
    total_size = 0
    user_folder = str(session["user_id"])

    try:
        result = (
            supabase.storage
            .from_(BUCKET_NAME)
            .list(user_folder)
        )

        for item in result:

            name = item.get("name", "")

            if not name:
                continue

            metadata = item.get("metadata") or {}

            if not metadata and item.get("id") is None:
                continue

            size = int(metadata.get("size", 0) or 0)
            total_size += size

            files.append({
                "name": name,
                "path": f"{user_folder}/{name}",
                "size": size,
            })

    except Exception:
        app.logger.exception("Could not load cloud files")
        flash("Could not load cloud files. Check the server terminal.")

    storage_used_mb = round(total_size / (1024 * 1024), 2)
    storage_percentage = min((storage_used_mb / 1000) * 100, 100)

    return render_template(
        "dashboard.html",
        files=files,
        storage_used_mb=storage_used_mb,
        storage_percentage=storage_percentage,
    )


# ==================================================
# UPLOAD
# ==================================================

@app.route("/upload", methods=["POST"])
@login_required
def upload_file():

    uploaded_file = request.files.get("file")

    if not uploaded_file or not uploaded_file.filename:
        flash("Please select a file first.")
        return redirect(url_for("dashboard"))

    original_name = secure_filename(uploaded_file.filename)

    if not original_name:
        flash("Invalid filename.")
        return redirect(url_for("dashboard"))

    user_folder = str(session["user_id"])
    cloud_path = f"{user_folder}/{uuid4().hex}_{original_name}"

    try:
        file_data = uploaded_file.read()

        if not file_data:
            flash("The selected file is empty.")
            return redirect(url_for("dashboard"))

        supabase.storage.from_(BUCKET_NAME).upload(
            path=cloud_path,
            file=file_data,
            file_options={
                "content-type": (
                    uploaded_file.mimetype or "application/octet-stream"
                ),
                "upsert": "false",
            },
        )

        flash(f"{original_name} uploaded successfully!")

    except Exception:
        app.logger.exception("File upload failed")
        flash("Upload failed. Check the server terminal.")

    return redirect(url_for("dashboard"))


# ==================================================
# CHECK FILE OWNERSHIP
# ==================================================

def get_user_file_path(filename):
    user_id = str(session.get("user_id", ""))

    if not user_id or not filename:
        return None

    # Remove leading slash if present
    filename = filename.lstrip("/")

    # Accept only files inside the logged-in user's folder
    if not filename.startswith(user_id + "/"):
        return None

    relative_name = filename[len(user_id) + 1:]

    # Prevent access to nested or invalid paths
    if (
        not relative_name
        or "/" in relative_name
        or "\\" in relative_name
        or relative_name in (".", "..")
    ):
        return None

    return f"{user_id}/{relative_name}"


# ==================================================
# PREVIEW
# ==================================================

@app.route("/preview/<path:filename>")
@login_required
def preview_file(filename):

    cloud_path = get_user_file_path(filename)

    if not cloud_path:
        flash("You cannot access this file.")
        return redirect(url_for("dashboard"))

    stored_name = cloud_path.rsplit("/", 1)[-1]
    original_name = stored_name.split("_", 1)[-1]

    allowed_extensions = (
        ".pdf", ".png", ".jpg", ".jpeg",
        ".gif", ".webp", ".bmp",
    )

    if not original_name.lower().endswith(allowed_extensions):
        flash("Preview is available only for PDF and image files.")
        return redirect(url_for("dashboard"))

    try:
        file_data = (
            supabase.storage
            .from_(BUCKET_NAME)
            .download(cloud_path)
        )

        mimetype = (
            mimetypes.guess_type(original_name)[0]
            or "application/octet-stream"
        )

        return send_file(
            BytesIO(file_data),
            mimetype=mimetype,
            as_attachment=False,
            download_name=original_name,
        )

    except Exception:
        app.logger.exception("File preview failed")
        flash("Preview failed. Check the server terminal.")
        return redirect(url_for("dashboard"))



# ==================================================
# DOWNLOAD
# ==================================================

@app.route("/download/<path:filename>")
@login_required
def download_file(filename):

    cloud_path = get_user_file_path(filename)

    if not cloud_path:
        flash("You cannot access this file.")
        return redirect(url_for("dashboard"))

    stored_name = cloud_path.rsplit("/", 1)[-1]
    original_name = stored_name.split("_", 1)[-1]

    try:
        file_data = (
            supabase.storage
            .from_(BUCKET_NAME)
            .download(cloud_path)
        )

        return send_file(
            BytesIO(file_data),
            mimetype="application/octet-stream",
            as_attachment=True,
            download_name=original_name,
        )

    except Exception:
        app.logger.exception("File download failed")
        flash("Download failed. Check the server terminal.")
        return redirect(url_for("dashboard"))



# ==================================================
# DELETE
# ==================================================

@app.route("/delete/<path:filename>", methods=["POST"])
@login_required
def delete_file(filename):

    cloud_path = get_user_file_path(filename)

    if not cloud_path:
        flash("You cannot delete this file.")
        return redirect(url_for("dashboard"))

    try:
        supabase.storage.from_(BUCKET_NAME).remove([cloud_path])
        flash("File deleted successfully.")

    except Exception:
        app.logger.exception("File deletion failed")
        flash("Delete failed. Check the server terminal.")
        return redirect(url_for("dashboard"))

    return redirect(url_for("dashboard"))


# ==================================================
# RUN APPLICATION
# ==================================================

if __name__ == "__main__":
    app.run(debug=True)
